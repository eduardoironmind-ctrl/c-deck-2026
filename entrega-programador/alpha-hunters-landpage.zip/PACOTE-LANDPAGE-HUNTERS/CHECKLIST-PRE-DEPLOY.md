# Checklist · Antes de publicar

Marca cada item antes de subir em produção.

---

## 🔴 Bloqueantes (obrigatório fazer antes do deploy)

### Conteúdo
- [ ] **Remover meta `noindex,nofollow`** do `<head>` do `index.html`
- [ ] Substituir TODOS os `href="#"` por links reais
- [ ] Substituir TODOS os números de WhatsApp placeholder
- [ ] Confirmar com Eduardo: número WhatsApp principal
- [ ] Confirmar com Eduardo: links de checkout dos 3 pacotes (R$1k / R$2k / R$5k)
- [ ] Confirmar com Eduardo: URL final do domínio
- [ ] Conferir todos os textos (typos, frases incompletas)

### Tracking
- [ ] Instalar Google Analytics 4 (Eduardo fornece GA_MEASUREMENT_ID)
- [ ] Instalar Meta Pixel (Eduardo fornece PIXEL_ID)
- [ ] Definir eventos de conversão (Lead, InitiateCheckout, Purchase)
- [ ] Testar eventos via Meta Pixel Helper / GA DebugView

### SEO
- [ ] Adicionar tag `<link rel="canonical">` apontando pro domínio final
- [ ] Adicionar Open Graph image (criar `og-image.jpg` 1200x630)
- [ ] Criar favicon a partir do `simbolo.png`
- [ ] Criar `robots.txt` em `public/` com:
  ```
  User-agent: *
  Allow: /
  Sitemap: https://alpha-hunters.com.br/sitemap.xml
  ```
- [ ] Criar `sitemap.xml` em `public/`

### Performance
- [ ] Otimizar imagens (target: < 300KB cada)
  - logo-horizontal.png (867KB → meta < 200KB)
  - simbolo.png (619KB → meta < 100KB)
  - lobo-alpha-bg.jpg (611KB → meta < 250KB)
- [ ] Validar Lighthouse Performance ≥ 90
- [ ] Validar Lighthouse Accessibility ≥ 95

---

## 🟡 Importantes (recomendado antes do deploy)

### UX
- [ ] Testar TODOS os CTAs em mobile (iPhone real + Android real)
- [ ] Testar formulários se houver
- [ ] Validar tempo de carregamento em conexão 3G (DevTools throttling)
- [ ] Validar legibilidade em telas pequenas
- [ ] Testar com leitor de tela (NVDA / VoiceOver) - acessibilidade

### Compartilhamento
- [ ] Open Graph testado em https://www.opengraph.xyz
- [ ] Card aparece correto no WhatsApp (mandar link pra você mesmo e ver preview)
- [ ] Card aparece correto no LinkedIn
- [ ] Card aparece correto no Twitter/X

### Segurança
- [ ] HTTPS funcionando (Let's Encrypt ou Cloudflare)
- [ ] Headers de segurança configurados (X-Frame-Options, etc.)
- [ ] SSL grade A+ em https://www.ssllabs.com/ssltest/

---

## 🟢 Bonus (depois do deploy)

### Marketing
- [ ] Submeter URL no Google Search Console
- [ ] Solicitar indexação
- [ ] Criar conta no Bing Webmaster Tools (opcional)
- [ ] Configurar UTM parameters padrão pros links de divulgação
- [ ] Testar deep link mobile (se aplicável)

### Monitoramento
- [ ] Configurar uptime monitoring (UptimeRobot, Better Uptime - grátis)
- [ ] Alertas no Slack/email se site cair
- [ ] Google Search Console: alertas de queries problemáticas

### Otimização contínua
- [ ] Cloudflare Web Analytics ativado (grátis, sem cookies)
- [ ] Hotjar ou similar pra heatmap (opcional)
- [ ] Configurar A/B test pra variações de CTA (opcional)

---

## Validação final

Depois de TUDO marcado, gerar relatório de validação:

```bash
# Lighthouse via CLI (alternativa ao DevTools)
npm install -g lighthouse
lighthouse https://alpha-hunters.com.br --output html --output-path ./relatorio.html

# Open Graph
curl https://api.opengraph.io/api/1.1/site/https%3A%2F%2Falpha-hunters.com.br

# SSL
curl https://api.ssllabs.com/api/v3/analyze?host=alpha-hunters.com.br
```

Anexar relatórios na entrega final pro Eduardo.

---

## Sign-off

Quando estiver tudo OK:

- [ ] Eduardo aprovou conteúdo
- [ ] Eduardo aprovou identidade visual aplicada
- [ ] Eduardo recebeu o link final
- [ ] Programador documentou senhas/acessos em local seguro
- [ ] Repositório git transferido pro Eduardo (ou acesso compartilhado)

**Data do go-live:** ___/___/______
**Aprovado por:** _____________________
