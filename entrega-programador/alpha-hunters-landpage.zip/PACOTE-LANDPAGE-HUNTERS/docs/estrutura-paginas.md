# Estrutura técnica da landpage

> Mapeamento das seções do `public/index.html` pra facilitar edições.

---

## Visão geral

Landpage **single page** dividida em seções verticais. Cada seção tem comentário HTML identificador.

Pra navegar rapidamente no arquivo, use Cmd+F com o nome da seção em maiúsculas:

```
SEÇÃO: HERO
SEÇÃO: PROBLEMA
SEÇÃO: SOLUÇÃO
SEÇÃO: COMO FUNCIONA
SEÇÃO: SIMULAÇÕES
SEÇÃO: PACOTES
SEÇÃO: FAQ
SEÇÃO: CTA
SEÇÃO: FOOTER
```

---

## Estrutura HTML simplificada

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <!-- meta tags, fontes, CSS inline -->
</head>
<body>

  <header>...</header>

  <section class="hero">          <!-- HERO -->
  <section class="problema">      <!-- PROBLEMA -->
  <section class="solucao">       <!-- SOLUÇÃO -->
  <section class="como-funciona"> <!-- COMO FUNCIONA -->
  <section class="simulacoes">    <!-- SIMULAÇÕES (3 contas) -->
  <section class="pacotes">       <!-- PACOTES R$1k/2k/5k -->
  <section class="faq">           <!-- FAQ -->
  <section class="cta-final">     <!-- CTA FINAL -->

  <footer>...</footer>

</body>
</html>
```

---

## CSS organizado

Todo o CSS está **inline** no `<head>` (single file). Organização interna:

```css
/* 1. RESET e variáveis */
:root { ... }

/* 2. BASE (body, headings, links) */
body { ... }

/* 3. COMPONENTES (botões, cards, selos) */
.cta { ... }
.card { ... }
.selo { ... }

/* 4. LAYOUT (header, sections, footer) */
.hero { ... }
.problema { ... }

/* 5. UTILITÁRIOS */
.container { ... }
.text-center { ... }

/* 6. RESPONSIVE */
@media (max-width: 768px) { ... }
@media (max-width: 480px) { ... }
```

---

## Pontos de edição comuns

### Trocar título principal

Buscar:
```html
<!-- SEÇÃO: HERO -->
<h1>...</h1>
```

### Trocar CTA principal

Buscar (vários no arquivo):
```html
<a href="#" class="cta">
```

### Trocar valores dos pacotes

Buscar:
```html
<!-- SEÇÃO: PACOTES -->
```

Dentro tem 3 blocos de pacote (R$1.000 / R$2.000 / R$5.000). Cada um com título, lista de inclusos, CTA.

### Trocar simulações

Buscar:
```html
<!-- SEÇÃO: SIMULAÇÕES -->
```

3 colunas com:
- Conta R$300
- Conta R$500
- Conta R$1.000

Com projeções de residual em 1/3/5/10 anos.

---

## Decisões técnicas (por que está assim)

| Decisão | Motivo |
|---|---|
| Single page sem framework | Performance + simplicidade + zero dependências |
| CSS inline | Reduz requests, melhora First Paint |
| Sem JavaScript | Não precisa pra essa landpage (CTAs são links) |
| Google Fonts CDN | Caching agressivo + fontes oficiais marca Alpha |
| Mobile-first | Maioria do tráfego virá de mobile |
| `noindex,nofollow` atual | Proteção durante desenvolvimento |

---

## Se precisar adicionar JavaScript

Caso futuramente precise (formulário, animações, tracking customizado):

1. Adicionar `<script>` antes do fechamento `</body>`
2. Manter inline pra simplicidade (sem build step)
3. Ou criar `public/js/main.js` e linkar

Evitar:
- jQuery (overhead desnecessário)
- React/Vue (não justifica em landpage estática)
- Bundlers (mantém zero build step)

---

## Estrutura de pastas no servidor

```
public/                      ← Document root
├── index.html
├── robots.txt              (criar antes do deploy)
├── sitemap.xml             (criar antes do deploy)
└── assets/
    ├── logo-horizontal.png
    ├── simbolo.png
    ├── lobo-alpha-bg.jpg
    ├── og-image.jpg        (criar antes do deploy · 1200x630)
    ├── favicon.png         (criar antes do deploy · 32x32)
    └── apple-touch-icon.png (criar antes do deploy · 180x180)
```
