# Identidade Visual · Alpha Hunters

> Brand guidelines oficiais da marca Alpha aplicadas nessa landpage.
> ⚠️ Não alterar sem aprovação de Eduardo Ferreira.

---

## Paleta de cores

### Primárias (oficial)

| Nome | Hex | Uso |
|---|---|---|
| Azul Militar | `#0D1F2D` | Background principal |
| Dourado | `#C8A951` | Accent, CTAs, destaques |
| Creme | `#F5F0E6` | Texto sobre fundo escuro |

### Variações de profundidade

```
Azul profundo     #050D14  (background extremo)
Azul meio         #0A1825  (intermediário)
Dourado claro     #E5C97A  (hover/focus)
Dourado escuro    #9A7E38  (pressed)
Creme escuro      #E8DFC9  (texto secundário)
```

### Apoio funcional

```
Verde   #6FA372  (sucesso, checks, valores positivos)
Vermelho #C24D3F  (alerta, valores negativos)
Azul info #6B9AC4  (informação neutra)
```

### Bordas e divisores

```
--linha:               rgba(245, 240, 230, 0.12)  /* sutil */
--linha-dourada:       rgba(200, 169, 81, 0.25)
--linha-dourada-forte: rgba(200, 169, 81, 0.45)
```

---

## Tipografia

### Famílias oficiais

| Fonte | Uso | Pesos usados |
|---|---|---|
| **Bodoni Moda** | Títulos H1, H2 | 400, 500, 700 + itálico |
| **Plus Jakarta Sans** | Corpo de texto | 300, 400, 500, 600, 700, 800 |
| **Bebas Neue** | Selos, labels curtos | 400 (único disponível) |

### Hierarquia recomendada

```css
h1 { font-family: 'Bodoni Moda', serif; font-size: clamp(36px, 5.5vw, 58px); font-weight: 500; }
h2 { font-family: 'Bodoni Moda', serif; font-size: clamp(28px, 3.5vw, 42px); font-weight: 500; }
h3 { font-family: 'Bodoni Moda', serif; font-size: 22px; }
p  { font-family: 'Plus Jakarta Sans'; font-size: 16px; line-height: 1.7; }
.selo, .label {
  font-family: 'Bebas Neue';
  letter-spacing: 0.32em;
  text-transform: uppercase;
  font-size: 11px;
}
```

### Carregamento

Via Google Fonts CDN:

```html
<link href="https://fonts.googleapis.com/css2?family=Bodoni+Moda:ital,wght@0,400;0,500;0,700;1,400;1,700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Bebas+Neue&display=swap" rel="stylesheet">
```

⚠️ **Não trocar pra fontes equivalentes ou similares.** São oficiais da marca.

---

## Logos e símbolos

Arquivos em `public/assets/`:

| Arquivo | Uso |
|---|---|
| `logo-horizontal.png` | Header, footer, contextos largos |
| `simbolo.png` | Favicon, selos pequenos, social avatars |
| `lobo-alpha-bg.jpg` | Background do hero, contextos imersivos |

### ⚠️ Regra absoluta

**NUNCA recriar logos, símbolos, badges, watermarks em SVG ou código.**

- Se precisar de variação visual nova → solicitar arquivo original ao Eduardo
- Eduardo delega criação ao ChatGPT/DALL-E via prompt curto
- Confirmado pelo cliente em 2026-05-20

### Otimização

Os arquivos atuais estão pesados pro web. Antes do deploy:

```bash
# Reduzir PNGs (mantém transparência)
pngquant --quality=85-95 logo-horizontal.png
pngquant --quality=85-95 simbolo.png

# Otimizar JPG do background
jpegoptim --max=85 lobo-alpha-bg.jpg

# OU criar versões WebP modernas
cwebp -q 85 logo-horizontal.png -o logo-horizontal.webp
cwebp -q 85 lobo-alpha-bg.jpg -o lobo-alpha-bg.webp
```

---

## Tom e voz

A copy da landpage segue o tom oficial Alpha:

### ✅ É

- Premium, calmo, exclusivo
- Direto sem ser agressivo
- Técnico quando necessário (números, simulações)
- Pessoal (primeira pessoa quando apropriado)
- Ambiente de **consequência**, não de cobrança

### ❌ Não é

- Militante, panfletário, "guerreiro"
- Agressivo ("você TEM que", "é OBRIGAÇÃO sua")
- Genérico, motivacional vazio
- Usar termos como: "batalha", "guerra", "soldado", "exército", "tribo"

⚠️ **Regra crítica confirmada pelo cliente:** sem militância. Disciplina virou consequência, não bandeira.

---

## Hierarquia narrativa

Toda comunicação Alpha segue essa hierarquia:

```
Ecossistema Alpha (acima · pequeno)
        ↓
Comunidade Alpha (a CASA · foco principal)
        ↓
Alpha Hunters (a PROFISSÃO · porta de entrada)
        ↓
Matrix (o VEÍCULO · motor financeiro)
```

**Nunca inverter.** A landpage atualmente foca Hunters (porta de entrada), mas a narrativa precisa abrir pra Matrix e culminar em Comunidade Alpha como destino.

---

## Componentes visuais

A landpage usa esses componentes recorrentes (estilo definido no `<style>` do `index.html`):

- **Selo dourado** (`.selo`) — label pequena destacada
- **Card escuro com borda dourada** — blocos de conteúdo
- **CTA dourado** (`.cta`) — botões principais
- **Divisor sutil** — entre seções (linha creme transparente)
- **Citação destacada** — frases-chave em Bodoni itálico

Pra criar novos componentes, seguir o sistema visual já estabelecido. Não introduzir cores/fontes novas.

---

## Referências oficiais (acervo Eduardo)

- Tipografia validada: `tipografia-alpha-final.html`
- Brand book: pasta `ALPHA-CENTRAL/01-BRANDBOOKS-TEXTO/`
- Identidade visual completa: `ALPHA-CENTRAL/04-IDENTIDADE-VISUAL/`
