# Alpha Hunters · Landpage Funil de Recrutamento

> Pacote pronto pra deploy em produção.
> Cliente: Eduardo Ferreira · Marca: Alpha Hunters

---

## O que tem nesse pacote

```
alpha-hunters-landpage/
├── README.md                # Este arquivo (visão geral)
├── DEPLOY.md                # Como subir no servidor (passo a passo)
├── CUSTOMIZACAO.md          # Como editar textos, links, cores
├── CHECKLIST-PRE-DEPLOY.md  # Validações antes de publicar
├── public/                  # 👈 O QUE VAI PRO DOMÍNIO
│   ├── index.html           # Landpage principal (single page)
│   └── assets/              # Imagens
│       ├── logo-horizontal.png
│       ├── simbolo.png
│       └── lobo-alpha-bg.jpg
└── docs/
    ├── identidade-visual.md  # Brand guidelines (cores, fontes)
    ├── estrutura-paginas.md  # Mapeamento das seções
    └── exemplo-nginx.conf    # Config Nginx exemplo
```

---

## TL;DR pro deploy

1. Faz upload da pasta `public/` pro servidor (ou seu CDN/S3)
2. Aponta o domínio pra `public/index.html`
3. Configura HTTPS (Let's Encrypt ou similar)
4. Pronto.

A landpage é **single page estática** (HTML + CSS + imagens). **Não tem build step, não tem dependência de Node/npm, não precisa de banco de dados, não precisa de PHP/Python no servidor**. Qualquer servidor de arquivos estáticos serve: Nginx, Apache, Cloudflare Pages, Netlify, Vercel, S3+CloudFront, etc.

---

## Especificações técnicas

| Item | Valor |
|---|---|
| Tipo | Landing page estática |
| Tecnologia | HTML5 + CSS3 puro (sem JS framework) |
| Tamanho total | ~2,2 MB |
| Páginas | 1 (single page com seções) |
| Responsive | Sim (mobile-first) |
| Fontes | Google Fonts (Bodoni Moda, Plus Jakarta Sans, Bebas Neue) |
| Imagens | 3 (logo, símbolo, background) |
| Dependências externas | Apenas Google Fonts |
| Build step | Nenhum |
| Performance esperada | Lighthouse 95+ |
| SEO | `noindex,nofollow` (intencionalmente fora do Google) |

---

## Antes de subir em produção

⚠️ **Importante:** A meta tag atual está como `noindex,nofollow` (proteção durante desenvolvimento). Quando for liberar pra o Google, edite no `<head>`:

```html
<!-- ANTES (desenvolvimento) -->
<meta name="robots" content="noindex,nofollow">

<!-- DEPOIS (produção) -->
<meta name="robots" content="index,follow">
```

Veja o `CHECKLIST-PRE-DEPLOY.md` pra lista completa de validações.

---

## Customização

Toda customização (textos, links, CTAs, cores) está documentada em `CUSTOMIZACAO.md`. O HTML está comentado por seções pra facilitar localização.

---

## Suporte

Dúvidas técnicas ou ajustes: contato direto com Eduardo Ferreira.
