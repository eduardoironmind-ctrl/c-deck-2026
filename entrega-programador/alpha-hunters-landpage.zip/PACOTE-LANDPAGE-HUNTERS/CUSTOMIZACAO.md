# Customização · O que editar e onde

Este documento mapeia tudo que você possivelmente vai precisar editar na landpage.

⚠️ **Antes de editar:** faça uma cópia de backup do `public/index.html`. O arquivo é único — qualquer edição é direta nele.

---

## 1. Textos · onde está o quê

Toda a landpage está em `public/index.html`. O HTML está estruturado em blocos comentados:

```html
<!-- ============================================================
     SEÇÃO: HERO
     ============================================================ -->
```

Use Ctrl+F (Cmd+F no Mac) pra localizar cada seção:

| Buscar por | Seção |
|---|---|
| `SEÇÃO: HERO` | Topo / primeira dobra |
| `SEÇÃO: PROBLEMA` | Bloco de dor do prospect |
| `SEÇÃO: SOLUÇÃO` | O que Hunters é |
| `SEÇÃO: COMO FUNCIONA` | Passo a passo |
| `SEÇÃO: SIMULAÇÕES` | 3 contas (R$300/500/1k) |
| `SEÇÃO: PACOTES` | 3 pacotes Hunters |
| `SEÇÃO: FAQ` | Perguntas frequentes |
| `SEÇÃO: CTA` | Bloco de conversão final |
| `SEÇÃO: FOOTER` | Rodapé |

---

## 2. Cores · paleta canônica Alpha

⚠️ **Não alterar sem aprovação do cliente.** A paleta é oficial da marca Alpha.

```css
:root {
  --azul-militar:   #0D1F2D;   /* primary · backgrounds escuros */
  --azul-profundo:  #050D14;   /* mais escuro · contraste extremo */
  --azul-meio:      #0A1825;   /* intermediário */
  --dourado:        #C8A951;   /* accent principal · CTAs, destaques */
  --dourado-claro:  #E5C97A;   /* hover state do dourado */
  --dourado-escuro: #9A7E38;   /* pressed state */
  --creme:          #F5F0E6;   /* texto sobre fundo escuro */
  --creme-escuro:   #E8DFC9;   /* texto secundário */
  --verde:          #6FA372;   /* sucesso · checks */
  --vermelho:       #C24D3F;   /* alerta · negativo */
}
```

Pra ajustar uma cor: edite só essa linha do `:root` no `<style>` do `index.html`. Toda a página atualiza.

---

## 3. Tipografia · fontes canônicas

```
Bodoni Moda       → títulos (h1, h2)
Plus Jakarta Sans → corpo de texto
Bebas Neue        → destaques curtos (selos, labels, números grandes)
```

Carregadas via Google Fonts no `<head>`:

```html
<link href="https://fonts.googleapis.com/css2?family=Bodoni+Moda...&family=Plus+Jakarta+Sans...&family=Bebas+Neue&display=swap" rel="stylesheet">
```

Não trocar fontes sem aprovação. São oficiais da marca.

---

## 4. Links e CTAs · pontos de conversão

Os CTAs hoje estão como placeholders. **Substituir antes do deploy:**

### Buscar no HTML por `href="#"` ou `href="https://wa.me/"`

Cada um precisa ser:

```html
<!-- WhatsApp · CTA principal -->
<a href="https://wa.me/55XXXXXXXXXXX?text=Oi%20Eduardo,%20vim%20da%20landpage%20Hunters">

<!-- Outros possíveis -->
<a href="https://link-do-checkout-pacote-1k">    <!-- Pacote básico -->
<a href="https://link-do-checkout-pacote-2k">    <!-- Pacote intermediário -->
<a href="https://link-do-checkout-pacote-5k">    <!-- Pacote completo -->
```

**📋 Lista de links a confirmar com Eduardo:**
- [ ] Número WhatsApp principal
- [ ] Link de pagamento Pacote R$1.000 (12x)
- [ ] Link de pagamento Pacote R$2.000 (12x)
- [ ] Link de pagamento Pacote R$5.000 (12x)
- [ ] Link do vídeo Matrix (7 min, obrigatório no funil)
- [ ] Link/embed do vídeo VSL principal
- [ ] Página de obrigado / pós-conversão

---

## 5. Imagens · trocar ou ajustar

Estão em `public/assets/`:

| Arquivo | Uso atual | Recomendação |
|---|---|---|
| `logo-horizontal.png` | Header | Manter (oficial Alpha) |
| `simbolo.png` | Selo / favicon | Manter |
| `lobo-alpha-bg.jpg` | Background hero | Manter |

### ⚠️ Regra crítica do cliente

**NUNCA recriar logos, símbolos, badges em SVG ou código.** Se precisar de variações visuais novas, solicitar arquivo original ao Eduardo (que delega criação ao ChatGPT/DALL-E). Confirmado pelo cliente em 2026-05-20.

### Otimização (recomendado)

As imagens estão pesadas pro web:
- `logo-horizontal.png` → 867 KB
- `simbolo.png` → 619 KB
- `lobo-alpha-bg.jpg` → 611 KB

Sugiro otimizar antes do deploy:

```bash
# Instalar ferramentas
brew install imagemagick webp pngquant jpegoptim

# Reduzir PNGs
pngquant --quality=80-95 --output public/assets/logo-otimizado.png public/assets/logo-horizontal.png
pngquant --quality=80-95 --output public/assets/simbolo-otimizado.png public/assets/simbolo.png

# Otimizar JPG
jpegoptim --max=85 public/assets/lobo-alpha-bg.jpg

# OU converter pra WebP (browser modernos)
cwebp -q 85 public/assets/logo-horizontal.png -o public/assets/logo-horizontal.webp
cwebp -q 85 public/assets/lobo-alpha-bg.jpg -o public/assets/lobo-alpha-bg.webp
```

Target: cada imagem com no máximo 150-300 KB.

---

## 6. Tracking · pixels e analytics

Hoje a landpage **não tem tracking instalado**. Antes do deploy em produção, adicionar no `<head>` (após `<title>`):

```html
<!-- Google Analytics 4 (substituir GA_MEASUREMENT_ID) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>

<!-- Meta Pixel (Facebook/Instagram) (substituir PIXEL_ID) -->
<script>
!function(f,b,e,v,n,t,s){...}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', 'PIXEL_ID');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=PIXEL_ID&ev=PageView&noscript=1"/></noscript>
```

**Eventos a trackear (sugestão):**
- `PageView` (automático no carregamento)
- `Lead` (clique em qualquer CTA WhatsApp)
- `InitiateCheckout` (clique em link de pagamento de pacote)
- `Purchase` (página de obrigado pós-pagamento)

---

## 7. SEO · meta tags

### Atual

```html
<title>Alpha Hunters · A profissão mais inteligente de 2026</title>
<meta property="og:title" content="...">
<meta property="og:description" content="...">
<meta name="robots" content="noindex,nofollow">  <!-- ⚠️ MUDAR EM PRODUÇÃO -->
```

### Adicionar antes do deploy

```html
<!-- Canonical -->
<link rel="canonical" href="https://alpha-hunters.com.br/">

<!-- Open Graph completo -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://alpha-hunters.com.br/">
<meta property="og:image" content="https://alpha-hunters.com.br/assets/og-image.jpg">
<meta property="og:locale" content="pt_BR">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Alpha Hunters · A profissão mais inteligente de 2026">
<meta name="twitter:description" content="...">
<meta name="twitter:image" content="https://alpha-hunters.com.br/assets/og-image.jpg">

<!-- Favicon (criar a partir do simbolo.png) -->
<link rel="icon" type="image/png" href="/assets/favicon.png">
<link rel="apple-touch-icon" href="/assets/apple-touch-icon.png">
```

---

## 8. Responsividade · breakpoints

A página já é mobile-first. Breakpoints usados:

```css
@media (max-width: 768px)  { /* tablet */ }
@media (max-width: 480px)  { /* mobile */ }
```

Testar em:
- iPhone (Safari)
- Android (Chrome)
- iPad
- Desktop (1280px+)

---

## 9. Performance · checklist final

- [ ] Imagens otimizadas (< 300KB cada)
- [ ] Gzip/Brotli ativo no servidor
- [ ] HTTP/2 ou HTTP/3
- [ ] Cache-Control configurado
- [ ] Lighthouse Performance ≥ 90
- [ ] First Contentful Paint < 1.5s
- [ ] Largest Contentful Paint < 2.5s
- [ ] CLS < 0.1
