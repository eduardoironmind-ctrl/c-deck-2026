# Deploy · Cloudflare Pages

**Opção escolhida pelo cliente:** Cloudflare Pages (grátis, HTTPS automático, CDN global, deploy via git push).

---

## TL;DR

1. Subir pasta `public/` num repo Git
2. Conectar repo no Cloudflare Pages
3. Apontar domínio
4. Pronto

Tempo estimado: **15 minutos**.

---

## Passo a passo detalhado

### 1. Criar repositório Git

```bash
cd alpha-hunters-landpage
git init
git add public/
git commit -m "initial deploy - alpha hunters landpage"
```

### 2. Subir pro GitHub (ou GitLab/Bitbucket)

Criar repo novo em github.com (privado é OK), depois:

```bash
git remote add origin git@github.com:USUARIO/alpha-hunters-landpage.git
git branch -M main
git push -u origin main
```

### 3. Conectar no Cloudflare Pages

1. Acessa **dash.cloudflare.com** → **Workers & Pages** → **Create application** → **Pages**
2. Clica **Connect to Git**
3. Autoriza acesso ao GitHub
4. Seleciona o repositório `alpha-hunters-landpage`
5. Configurações de build:
   - **Project name:** `alpha-hunters` (vai gerar `alpha-hunters.pages.dev`)
   - **Production branch:** `main`
   - **Framework preset:** `None`
   - **Build command:** *(deixar VAZIO)*
   - **Build output directory:** `public`
   - **Root directory:** *(deixar vazio)*
6. Clica **Save and Deploy**

Em ~1 minuto a landpage está no ar em `https://alpha-hunters.pages.dev` (ou nome similar).

### 4. Apontar domínio próprio

Quando Eduardo confirmar o domínio final (ex: `alpha-hunters.com.br`):

1. No projeto Pages → **Custom domains** → **Set up a custom domain**
2. Digita o domínio (ex: `alpha-hunters.com.br`)
3. Cloudflare instrui as configurações DNS:
   - Se o domínio JÁ está no Cloudflare: configura automaticamente
   - Se está em outro registrador: aponta NS pro Cloudflare (recomendado) OU adiciona CNAME no DNS atual
4. HTTPS é configurado automático em ~5 minutos
5. Adicionar também o `www.alpha-hunters.com.br` apontando pro mesmo

---

## Atualizações futuras

Toda vez que precisar atualizar a landpage (texto, imagem, etc.):

```bash
# Edita os arquivos em public/
# Faz commit e push:
git add .
git commit -m "ajuste: <descrição>"
git push

# Cloudflare faz deploy automático em ~30 segundos
```

Histórico de versões fica no GitHub. Rollback fácil.

---

## Configurações Cloudflare recomendadas

No painel do projeto Pages:

### Speed
- **Auto Minify:** ativar HTML/CSS/JS
- **Brotli:** já vem ativo
- **Early Hints:** ativar

### Caching
- **Browser Cache TTL:** 4 hours
- **Edge Cache TTL:** 1 month

### Security
- **Always Use HTTPS:** ativar
- **Minimum TLS Version:** 1.2
- **HSTS:** ativar (após confirmar HTTPS funcionando)

### Headers customizados (opcional)

Criar arquivo `public/_headers`:

```
/*
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(), microphone=(), camera=()

/assets/*
  Cache-Control: public, max-age=31536000, immutable
```

---

## Pós-deploy · validações obrigatórias

```
✅ Site abre em https://alpha-hunters.com.br
✅ Redirect de http → https funciona
✅ www e sem-www funcionam ambos
✅ Mobile testado em iPhone E Android REAIS
✅ Lighthouse Performance ≥ 90
✅ Open Graph testado em https://www.opengraph.xyz
✅ SSL grade A+ em https://www.ssllabs.com/ssltest/
✅ Todos os CTAs apontam pros links corretos
✅ Meta tag noindex REMOVIDA (ver CUSTOMIZACAO.md)
```

---

## Próximos passos

Antes de subir em produção, ver:

- `CUSTOMIZACAO.md` — todos os textos, links e configs que precisam ser ajustados
- `CHECKLIST-PRE-DEPLOY.md` — validações obrigatórias antes de publicar

---

## Suporte

Dúvidas técnicas: contato direto com Eduardo Ferreira.
